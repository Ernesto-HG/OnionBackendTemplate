﻿using Microsoft.AspNetCore.Mvc;
using andon_ng.Core.Entities;
using andon_ng.Application.Services;

namespace andon_ng.API.Controllers
{
    [Controller]
    [Route("/api/entity")]
    public class EntityController : ControllerBase
    {
        private readonly EntityService entityService;
        public EntityController(EntityService entityService)
        {
            this.entityService = entityService ?? throw new ArgumentNullException(nameof(entityService));
        }

        [HttpGet]
        public async Task<IEnumerable<TestEntity>> GetEntities()
        {
            return await entityService.GetEntitiesAsync();
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<TestEntity>> GetEntity(Guid id)
        {
            var entity = await entityService.GetEntities(id);

            if (entity == null)
            {
                return NotFound();
            }

            return entity;
        }

        [HttpPost]
        public async Task<ActionResult<TestEntity>> AddEntity([FromBody] TestEntity entity)
        {
            if (entity == null)
            {
                return StatusCode(501, "No se otorgó una entidad que guardar");
            }

            await entityService.AddEntity(entity);

            return CreatedAtAction(nameof(GetEntity), new { id = entity.Id_entity }, entity);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEntity(Guid id, [FromBody] TestEntity updatedEntity)
        {
            var existingEntity = await entityService.GetEntities(id);
            if (existingEntity == null)
            {
                return NotFound();
            }
            //ej: existingEntity.Nombre_de_Entity = updatedEntity.Nombre_de_Entity;
            await entityService.UpdateEntity(id, existingEntity);

            return Ok(existingEntity);
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEntity(Guid id)
        {
            var Entity = await entityService.GetEntities(id);
            if (Entity == null)
            {
                return NotFound();
            }

            await entityService.DeleteEntity(id);

            return Ok();
        }
    }
}




