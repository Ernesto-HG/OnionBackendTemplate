using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;

using andon_ng.Core.Interfaces;
using andon_ng.Infrastructure.Data;
using andon_ng.Infrastructure.Repositories;
using andon_ng.Application.Services;


var builder = WebApplication.CreateBuilder(args);
builder.Configuration
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables();

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//add dbcontext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer("Server=JYGAERNESTO\\ANDONNGSERVER;Database=Andon_Ng;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;"));

//add created repositories and services for the entities
//ej:
builder.Services.AddScoped<IRepositoryEntity, RepositoryEntity>();
builder.Services.AddScoped<EntityService>();


//add cors
//builder.Services.AddCors(options =>
//{
//    options.AddPolicy("AllowAllOrigins", policy =>
//    {
//        policy.AllowAnyOrigin()
//              .AllowAnyHeader()
//              .AllowAnyMethod();
//    });
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowAllOrigins");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();